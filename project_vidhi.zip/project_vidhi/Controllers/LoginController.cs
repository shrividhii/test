﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;
using static System.Web.Razor.Parser.SyntaxConstants;
using System.Web.Optimization;
using System.Web.UI.WebControls;
using project_vidhi.Models;
using System.Web.Routing;

namespace project_vidhi.Controllers
{
    public class LoginController : Controller
    {
        public ActionResult Index()
        {

            return View();
        }

        [HttpPost]
        public JsonResult Authenticate(String username, String password)
        {
           if (username == "vidhi" && password == "vidhi1234")
            {
                Session["username"] = username;
                return Json(new { Success = true});
            }
            else if (username == "admin" && password == "admin")
            {
                return Json(new { Success = true });
            }
            else
                return Json(new { Success = false });
        }
         
        //public List<LoginAuthentication> putVlaue()
        //{
        //    var users = new List<LoginAuthentication>();
        //    {
        //        new LoginAuthentication { Username = "vidhi", Password = "vidhi1234" };
                
        //        new LoginAuthentication { Username = "admin", Password = "admin" };
        //    };
        //    return users;
        //}

        //[HttpPost]
        //public ActionResult Verify(LoginAuthentication usr) 
        //{
        //    var u = putVlaue();

        //    var ue = u.Where(ur => ur.Username.Equals(usr.Username));
        //    var up = u.Where(p => p.Username.Equals(usr.Username));

        //    if(up.Count()==1)
        //    {
        //        return RedirectToAction("AdminProfile", "User");
        //    }
        //    else
        //    {
        //        return RedirectToAction("UserProfile", "User");
        //    }
        //}
        
    }
}
